
        var number1 = document.querySelector("input #number1")
        var number2 = document.querySelector("input #number2")
        var result = document.getElementById("result")
        //var operator = document.getElementById("operator").value

        result.innerHTML = "oi"

        function showResult(){


           
        }